package Lab1;

public class Experimental2_1 
{
	public static void main(String[] args) 
	{
		System.out.println("Welcom to Java, Welcome to Computer Science, and Programming is fun");
	}
}
